
document.addEventListener("DOMContentLoaded", () => {
    // Napi tipp funkció
    const tips = [
        "Vegyél egy mély levegőt és számolj háromig.",
        "Sétálj egyet a friss levegőn.",
        "Írd le, mi miatt vagy hálás.",
        "Hallgass meg egy kedvenc zenédet.",
        "Igyál egy pohár vizet tudatosan, lassan."
    ];
    const tipButton = document.getElementById("show-tip");
    const tipDisplay = document.getElementById("daily-tip");
    tipButton.addEventListener("click", () => {
        const randomTip = tips[Math.floor(Math.random() * tips.length)];
        tipDisplay.textContent = randomTip;
    });

    // Stressz csúszka érték
    const slider = document.getElementById("stress-slider");
    const sliderValue = document.getElementById("slider-value");
    slider.addEventListener("input", () => {
        sliderValue.textContent = slider.value;
    });

    // Napló mentés és visszanézés
    const saveButton = document.getElementById("save-entry");
    const diaryText = document.getElementById("diary-text");
    const entryList = document.getElementById("entry-list");

    function loadEntries() {
        const entries = JSON.parse(localStorage.getItem("entries") || "[]");
        entryList.innerHTML = "";
        entries.forEach(entry => {
            const li = document.createElement("li");
            li.textContent = `${entry.date} - Stressz: ${entry.stress}/10 - ${entry.text}`;
            entryList.appendChild(li);
        });
    }

    saveButton.addEventListener("click", () => {
        const text = diaryText.value.trim();
        if (text === "") return;
        const entry = {
            date: new Date().toLocaleDateString(),
            text,
            stress: slider.value
        };
        const entries = JSON.parse(localStorage.getItem("entries") || "[]");
        entries.unshift(entry);
        localStorage.setItem("entries", JSON.stringify(entries));
        diaryText.value = "";
        loadEntries();
    });

    loadEntries();

    // Légzőgyakorlat animáció
    const breathCircle = document.getElementById("breath-circle");
    setInterval(() => {
        breathCircle.classList.toggle("expand");
    }, 4000);
});
